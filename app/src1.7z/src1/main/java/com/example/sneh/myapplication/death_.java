package com.example.sneh.myapplication;

/**
 * Created by Himanshu on 11/7/2015.
 */
public class death_ {
    private int death_id,cicle_id,building_id;
    private int sql_death_id,sql_cicle_id,sql_building_id;
    private int user_id;
    private int flag;
    private String date;
    private int death_no;

    public int getFlag() {
        return flag;
    }

    public void setFlag(int flag) {
        this.flag = flag;
    }

    public int getSql_building_id() {
        return sql_building_id;
    }

    public void setSql_building_id(int sql_building_id) {
        this.sql_building_id = sql_building_id;
    }

    public int getSql_cicle_id() {
        return sql_cicle_id;
    }

    public void setSql_cicle_id(int sql_cicle_id) {
        this.sql_cicle_id = sql_cicle_id;
    }

    public int getSql_death_id() {
        return sql_death_id;
    }

    public void setSql_death_id(int sql_death_id) {
        this.sql_death_id = sql_death_id;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public int getDeath_id() {
        return death_id;
    }

    public void setDeath_id(int equip_id) {
        this.death_id = equip_id;
    }

    public int getCicle_id() {
        return cicle_id;
    }

    public void setCicle_id(int cicle_id) {
        this.cicle_id = cicle_id;
    }

    public int getBuilding_id() {
        return building_id;
    }

    public void setBuilding_id(int building_id) {
        this.building_id = building_id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getDeath_no() {
        return death_no;
    }

    public void setDeath_no(int death_no) {
        this.death_no = death_no;
    }
}
