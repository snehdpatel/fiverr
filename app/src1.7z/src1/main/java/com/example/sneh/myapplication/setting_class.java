package com.example.sneh.myapplication;


public class setting_class {

    private String country;
    private String money_format;
    private String notification;


    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getMoney_format() {
        return money_format;
    }

    public void setMoney_format(String money_format) {
        this.money_format = money_format;
    }

    public String getNotification() {
        return notification;
    }

    public void setNotification(String notification) {
        this.notification = notification;
    }



}
