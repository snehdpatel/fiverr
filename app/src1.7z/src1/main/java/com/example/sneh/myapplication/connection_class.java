package com.example.sneh.myapplication;


import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.ClientError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;


public class connection_class {

    public void login(Context context,String email,String password){
        class  login extends  AsyncTask<String , Void ,String>{
            private Context con;
            private Dialog loading;
            private String email,password;
            public login(Context context) {
                con = context;
            }

            public void onPreExecute()
            {
                super.onPreExecute();
                loading = ProgressDialog.show(con, "please wait", "checking");
            }

            public String doInBackground(String... params) {
                email=params[0];
                password=params[1];
                Log.d("email",email);
                String data = null;
                String result="";
                try {
                    data = URLEncoder.encode("email", "UTF-8") + "=" + URLEncoder.encode(email, "UTF-8");
                    data += "&" + URLEncoder.encode("password", "UTF-8") + "=" + URLEncoder.encode(password, "UTF-8");

                    URL url = new URL("http://192.168.1.101/cicle/login.php");
                    URLConnection connection = url.openConnection();
                    connection.setDoOutput(true);
                    //Writting
                    OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream());
                    writer.write(data);
                    writer.flush();
                    //getting the input
                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    String line;

                    while ((line = reader.readLine()) != null) {
                        result = result + line;
                    }

                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                Log.d("result", result);
                return result;

            }
            public void onPostExecute(String result) {
                if (loading != null) {
                    loading.dismiss();
                }
                json_parsing json_parsing=new json_parsing();
                message_class message=json_parsing.login_register_parsing(result);
                Log.d("success",String.valueOf(message.getSuccess()));
                if(message.getSuccess()>0){
                    SharedPreferences pref=con.getSharedPreferences("user_data",Context.MODE_PRIVATE);
                    SharedPreferences.Editor edit=pref.edit();
                    edit.putInt("user_id", message.getSuccess());
                    Log.d("user_id", String.valueOf(message.getSuccess()));
                    Log.d("user_email", email);
                    Log.d("user_password", password);
                    edit.putString("user_email", email);
                    edit.putString("user_password", password);
                    edit.commit();
                    Toast.makeText(con,message.getMessage(),Toast.LENGTH_SHORT).show();
                    Intent intent=new Intent(con,Tasks.class);
                    con.startActivity(intent);
                }
                Toast.makeText(con, message.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
        login login=new login(context);
        login.execute(email,password);
    }

    public void register(Context context, String fname, String lname, String email, String password) {

        class register extends AsyncTask<String, Void, String> {
            private Context con;
            private Dialog loading;

            public register(Context context) {
                con = context;
            }

            public void onPreExecute()

            {
                super.onPreExecute();
                loading = ProgressDialog.show(con, "please wait", "checking");
            }

            public String doInBackground(String... params) {
                String fname = params[0];
                String lname = params[1];
                String email = params[2];
                Log.d("email",email);
                String password = params[3];
                String result = "";

                String data = null;
                try {
                    data = URLEncoder.encode("fname", "UTF-8") + "=" + URLEncoder.encode(fname, "UTF-8");
                    data += "&" + URLEncoder.encode("lname", "UTF-8") + "=" + URLEncoder.encode(lname, "UTF-8");
                    data += "&" + URLEncoder.encode("email", "UTF-8") + "=" + URLEncoder.encode(email, "UTF-8");
                    data += "&" + URLEncoder.encode("password", "UTF-8") + "=" + URLEncoder.encode(password, "UTF-8");
                    URL url = new URL("http://192.168.1.101/cicle/register.php");
                    URLConnection connection = url.openConnection();
                    connection.setDoOutput(true);
                    //Writting
                    OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream());
                    writer.write(data);
                    writer.flush();
                    //getting the input
                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    String line;

                    while ((line = reader.readLine()) != null) {
                        result = result + line;
                    }

                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                Log.d("result", result);
                return result;

            }

            public void onPostExecute(String result) {
                if (loading != null) {
                    loading.dismiss();
                }
                json_parsing json_parsing=new json_parsing();
                 message_class message=json_parsing.login_register_parsing(result);
                Toast.makeText(con,message.getMessage(),Toast.LENGTH_SHORT).show();
            }
        }
        register register=new register(context);
        register.execute(fname,lname,email,password);

    }

    public void sync_cicle(int user_id,String date,Context context){

        class sync extends  AsyncTask<String,Void,String>{
            private Context con;
            private Dialog loading;
            private String date;
            private  String user_id;

            public sync(Context context) {
                con = context;
            }

            public void onPreExecute()

            {
                super.onPreExecute();
                loading = ProgressDialog.show(con, "please wait", "checking");
            }

            public String doInBackground(String... params) {
                user_id=String.valueOf(params[0]);
                date=params[1];
                Log.d("con_user_id",user_id);
                Log.d("con_date",date);
                String data = null;
                String result="";
                try {
                    data = URLEncoder.encode("user_id", "UTF-8") + "=" + URLEncoder.encode(user_id, "UTF-8");
                    data += "&" + URLEncoder.encode("date", "UTF-8") + "=" + URLEncoder.encode(date, "UTF-8");

                    URL url = new URL("http://192.168.1.101/cicle/get_task.php");
                    URLConnection connection = url.openConnection();
                    connection.setDoOutput(true);
                    //Writting
                    OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream());
                    writer.write(data);
                    writer.flush();
                    //getting the input
                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    String line;

                    while ((line = reader.readLine()) != null) {
                        result = result + line;
                    }

                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                Log.d("result", result);
                return result;

            }
            public void onPostExecute(String result) {


                String message=result;
                json_parsing parsing=new json_parsing();
                parsing.json(con,message);
                if (loading != null) {
                    loading.dismiss();
                }
                Toast.makeText(con, message, Toast.LENGTH_SHORT).show();
            }
        }
        sync sync=new sync(context);
        sync.execute(String.valueOf(user_id),date);
    }

    public void get_task(int user_id,Context context){
        Calendar c = Calendar.getInstance();
        System.out.println("Current time => " + c.getTime());

        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        String formattedDate = df.format(c.getTime());
        Log.d("todays_date", formattedDate);
        post_task(formattedDate, user_id, context);
    }

    public void post_task(final String date, final int user_id, final Context context){
        JSONObject js=new JSONObject();

        try {
            js.put("date",date);
            js.put("user_id",user_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        String url = "http://192.168.1.101/cicle/get_task.php";
        RequestQueue queue=Volley.newRequestQueue(context);
        JsonObjectRequest jsonObjReq = new JsonObjectRequest(
                Request.Method.POST,url, js,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d("onse", response.toString());
                        json_parsing json_parsing=new json_parsing();
                        json_parsing.json(context,response.toString());

                    }
                }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                if( error instanceof NetworkError) {
                    Log.d("Error ","NetworkError");
                } else if( error instanceof ClientError) {
                    Toast.makeText(context,"Error in Connection",Toast.LENGTH_SHORT).show();
                } else if( error instanceof ServerError) {
                    Toast.makeText(context,"Server Error Connection Failed",Toast.LENGTH_SHORT).show();
                } else if( error instanceof AuthFailureError) {
                    Toast.makeText(context,"Authentication Failure",Toast.LENGTH_SHORT).show();
                } else if( error instanceof ParseError) {
                    Log.d("Error in parsing","Error in json_parsing");
                } else if( error instanceof NoConnectionError) {
                    Toast.makeText(context,"No Connection",Toast.LENGTH_SHORT).show();
                } else if( error instanceof TimeoutError) {
                    Log.d("TimeOut Error","TimeOut Error");
                }else{
                    Log.d("Unknown_error","unknown_error");
                }
            }

        }) {
            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String, String> headers = new HashMap<String, String>();
                headers.put("Content-Type", "application/json; charset=utf-8");
                return headers;
            }
        };
        jsonObjReq.setRetryPolicy(new DefaultRetryPolicy(0,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
        ));

        queue.add(jsonObjReq);

    }
}

