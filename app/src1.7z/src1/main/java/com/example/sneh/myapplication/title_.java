package com.example.sneh.myapplication;

/**
 * Created by sneh on 13/11/15.
 */
public class title_ {

    private int title_id,done;
    private String title;

    public int getTitle_id() {
        return title_id;
    }

    public void setTitle_id(int title_id) {
        this.title_id = title_id;
    }

    public int getDone() {
        return done;
    }

    public void setDone(int done) {
        this.done = done;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
