package com.example.sneh.myapplication;

/**
 * Created by Himanshu on 11/14/2015.
 */
public interface task_implement {

    public void respond(String data, int data1);

}
