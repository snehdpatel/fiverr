package com.example.sneh.myapplication;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Environment;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.ClientError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class sync_class {
    int size;
    Context context;
    ProgressDialog loading;

    List<cicle> cicle_list=new ArrayList<>();
    List<building_class> building_list=new ArrayList<>();
    List<equipment_> equip_list=new ArrayList<>();
    List<medical_> medical_list=new ArrayList<>();
    List<worker_class> worker_list=new ArrayList<>();
    List<food_class> food_list=new ArrayList<>();
    List<consommation_> con_list=new ArrayList<>();
    List<animal_class> animal_list=new ArrayList<>();
    List<death_> death_list=new ArrayList<>();
    List<returned_expense_class> returned_list=new ArrayList<>();
    List<additional_expense_class> additional_list=new ArrayList<>();
    List<down_payment_class> down_payment_list=new ArrayList<>();
    List<egg_n>normal_egg_list=new ArrayList<>();
    List<egg_b>broken_egg_list=new ArrayList<>();
    List<temp_>temp_list=new ArrayList<>();
    List<notes_file>note_list=new ArrayList<>();
    List<image_class> image_list=new ArrayList<>();
    db_handler handler;
    DataBaseHandler new_handler;
    int user_id;
    int i=0;

    public sync_class(Context con){
        context=con;
        handler=new db_handler(context);
        handler.onCreateTable(handler.getWritableDatabase());
        new_handler=new DataBaseHandler(context);
        new_handler.onCreateTable(handler.getWritableDatabase());
        loading=null;
    }

    public void get_list(){

        SharedPreferences preferences=context.getSharedPreferences("user_data",Context.MODE_PRIVATE);
        user_id=preferences.getInt("user_id",-1);
        cicle_list.addAll(handler.get_all_cicle(user_id));
        Log.d("sync_cicle_list_size", String.valueOf(cicle_list.size()));
        building_list.addAll(handler.getAllBuilding(user_id));
        Log.d("sync_build_list_size", String.valueOf(building_list.size()));
        equip_list.addAll(handler.get_all_equipment_by_user_id(user_id));
        Log.d("sync_equip_list_size", String.valueOf(equip_list.size()));
        worker_list.addAll(handler.get_all_worker_by_user_id(user_id));
        Log.d("sync_worker_list_size", String.valueOf(worker_list.size()));
        medical_list.addAll(handler.get_all_medical_by_user_id(user_id));
        Log.d("sync_medical_list_size", String.valueOf(medical_list.size()));
        food_list.addAll(handler.getAllFoodBYUSER_ID(user_id));
        Log.d("sync_food_list_size", String.valueOf(food_list.size()));
        con_list.addAll(handler.get_all_con_by_user_id(user_id));
        Log.d("sync_con_list_size", String.valueOf(con_list.size()));
        animal_list.addAll(handler.getAllAnimalByUser_id(user_id));
        Log.d("sync_animal_list_size", String.valueOf(animal_list.size()));
        death_list.addAll(handler.get_all_death_by_user_id(user_id));
        Log.d("sync_death_list_size", String.valueOf(death_list.size()));
        returned_list.addAll(handler.get_all_returned_expense_by_user_id(user_id));
        Log.d("sync_returned_list_size", String.valueOf(returned_list.size()));
        additional_list.addAll(handler.get_all_additional_expense_by_user_id(user_id));
        Log.d("sync_returned_list_size", String.valueOf(returned_list.size()));
        down_payment_list.addAll(handler.get_all_down_payment_by_user_id(user_id));
        Log.d("sync_returned_list_size", String.valueOf(returned_list.size()));
        normal_egg_list.addAll(handler.get_all_normal_egg_by_user_id(user_id));
        Log.d("sync_n_egg_list_size", String.valueOf(normal_egg_list.size()));
        broken_egg_list.addAll(handler.get_all_broken_egg_by_user_id(user_id));
        Log.d("sync_b_egg_list_size", String.valueOf(broken_egg_list.size()));
        temp_list.addAll(handler.get_all_temp_by_user_id(user_id));
        Log.d("sync_temp_list_size", String.valueOf(temp_list.size()));
        note_list.addAll(new_handler.get_all_note_by_user_id(user_id));
        Log.d("sync_note_list_size", String.valueOf(note_list.size()));
        image_list.addAll(handler.get_all_image_by_user_id(user_id));
        Log.d("sync_image_list_size",String.valueOf(image_list.size()));
    }

    public void get_json(){
        Gson gson=new Gson();
        String cicle_json=gson.toJson(cicle_list);
        String building_json=gson.toJson(building_list);
        String equip_json=gson.toJson(equip_list);
        String worker_json=gson.toJson(worker_list);
        String medical_json=gson.toJson(medical_list);
        String food_json=gson.toJson(food_list);
        String con_json=gson.toJson(con_list);
        String animal_json=gson.toJson(animal_list);
        String death_json=gson.toJson(death_list);
        String returned_expense_json=gson.toJson(returned_list);
        String additional_expense_json=gson.toJson(additional_list);
        String down_payment_json=gson.toJson(down_payment_list);
        String normal_egg_json=gson.toJson(normal_egg_list);
        String broken_egg_json=gson.toJson(broken_egg_list);
        String temp_json=gson.toJson(temp_list);
        String note_json=gson.toJson(note_list);
        String image_json=gson.toJson(image_list);
        JSONObject object=new JSONObject();
        try {
            object.put("user_id",user_id);
            object.put("cicle",cicle_json);
            object.put("building",building_json);
            object.put("equipment",equip_json);
            object.put("worker",worker_json);
            object.put("medical",medical_json);
            object.put("food",food_json);
            object.put("consommation",con_json);
            object.put("returned_expense",returned_expense_json);
            object.put("additional_expense",additional_expense_json);
            object.put("down_payment",down_payment_json);
            object.put("animal",animal_json);
            object.put("death",death_json);
            object.put("broken_egg",broken_egg_json);
            object.put("normal_egg",normal_egg_json);
            object.put("temp",temp_json);
            object.put("note",note_json);
            object.put("image",image_json);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        Log.d("Json_gson",object.toString());
        String res=object.toString().replace("\\","");
        Log.d("json_string", res);
        send_data(object, context);
    }

    public void send_data(JSONObject js, final Context context){
        String url = "http://192.168.1.101/cicle/parse_json.php";
        Log.d("sync_url",url);

        RequestQueue queue=Volley.newRequestQueue(context);
        if(loading==null) {
            Log.d("go_to_hell","go+to_hell");
            loading = ProgressDialog.show(context, "please wait", "checking");
        }
        JsonObjectRequest jsonObjReq = new JsonObjectRequest(
                Request.Method.POST,url, js,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d("onse", response.toString());
                        json_parsing parsing=new json_parsing();
                        parsing.get_list(cicle_list,building_list,equip_list,worker_list,medical_list,food_list,con_list,additional_list,returned_list,down_payment_list,animal_list,death_list,normal_egg_list,broken_egg_list,temp_list,note_list);
                        size=parsing.main_parse(response,context);
                        if(size>0){
                            sync_class.this.get_list();
                            sync_class.this.get_json();
                        }
                        else{
                            loading.hide();
                        }
                    }
                }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                if( error instanceof NetworkError) {
                    Log.d("Error ","NetworkError");
                } else if( error instanceof ClientError) {
                    Toast.makeText(context,"Error in Connection",Toast.LENGTH_SHORT).show();
                } else if( error instanceof ServerError) {
                    Toast.makeText(context,"Server Error Connection Failed",Toast.LENGTH_SHORT).show();
                } else if( error instanceof AuthFailureError) {
                    Toast.makeText(context,"Authentication Failure",Toast.LENGTH_SHORT).show();
                } else if( error instanceof ParseError) {
                    Log.d("Error in parsing","Error in json_parsing");
                } else if( error instanceof NoConnectionError) {
                    Toast.makeText(context,"No Connection",Toast.LENGTH_SHORT).show();
                } else if( error instanceof TimeoutError) {
                    Log.d("TimeOut Error","TimeOut Error");
                }else{
                    Log.d("Unknown_error","unknown_error");
                }            }

        }) {
            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String, String> headers = new HashMap<String, String>();
                headers.put("Content-Type", "application/json; charset=utf-8");
                return headers;
            }
        };
        jsonObjReq.setRetryPolicy(new DefaultRetryPolicy(0,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
        ));

        queue.add(jsonObjReq);
    }


    public void downloadfile_url(Context context){
        class DownloadFileFromURL extends AsyncTask<String, String, String> {
            Context context;
            ProgressDialog dialog;
            public DownloadFileFromURL(Context con){
                context=con;
            }

            /**
             * Before starting background thread Show Progress Bar Dialog
             * */
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                dialog=ProgressDialog.show(context,"Downloading Image","Stop");
            }

            /**
             * Downloading file in background thread
             * */
            @Override
            protected String doInBackground(String... f_url) {
                int count;
                try {
                    String url1="http://localhost/cicle/images/test.mp4";
                    URL url = new URL(url1);
                    URLConnection conection = url.openConnection();
                    conection.connect();

                    // this will be useful so that you can show a tipical 0-100%
                    // progress bar
                    int lenghtOfFile = conection.getContentLength();

                    // download the file
                    InputStream input = new BufferedInputStream(url.openStream(),
                            8192);

                    // Output stream
                    OutputStream output = new FileOutputStream(Environment
                            .getExternalStorageDirectory().toString()
                            + "/2");

                    byte data[] = new byte[1024];

                    long total = 0;

                    while ((count = input.read(data)) != -1) {
                        total += count;
                        // publishing the progress....
                        // After this onProgressUpdate will be called
                        publishProgress("" + (int) ((total * 100) / lenghtOfFile));

                        // writing data to file
                        output.write(data, 0, count);
                    }

                    // flushing output
                    output.flush();

                    // closing streams
                    output.close();
                    input.close();

                } catch (Exception e) {
                    Log.e("Error: ", e.getMessage());
                }

                return null;
            }

            /**
             * Updating progress bar
             * */

            /**
             * After completing background task Dismiss the progress dialog
             * **/
            @Override
            protected void onPostExecute(String file_url) {
                // dismiss the dialog after the file was downloaded
                dialog.dismiss();
            }

        }

        DownloadFileFromURL downloadFileFromURL=new DownloadFileFromURL(context);
        downloadFileFromURL.execute("hell");
    }



}
