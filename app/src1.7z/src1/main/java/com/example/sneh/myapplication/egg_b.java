package com.example.sneh.myapplication;

/**
 * Created by sneh on 13/11/15.
 */
public class egg_b {

    private int sql_broken_egg_id,sql_cicle_id,sql_building_id;
    private int user_id;
    private int number;
    private int egg_id,cicle_id,building_id;
    private String date,type;
    private int flag;

    public int getSql_broken_egg_id() {
        return sql_broken_egg_id;
    }

    public void setSql_broken_egg_id(int sql_broken_egg_id) {
        this.sql_broken_egg_id = sql_broken_egg_id;
    }

    public int getSql_cicle_id() {
        return sql_cicle_id;
    }

    public void setSql_cicle_id(int sql_cicle_id) {
        this.sql_cicle_id = sql_cicle_id;
    }

    public int getSql_building_id() {
        return sql_building_id;
    }

    public void setSql_building_id(int sql_building_id) {
        this.sql_building_id = sql_building_id;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public int getFlag() {
        return flag;
    }

    public void setFlag(int flag) {
        this.flag = flag;
    }



    public int getEgg_id() {
        return egg_id;
    }

    public void setEgg_id(int egg_id) {
        this.egg_id = egg_id;
    }

    public int getCicle_id() {
        return cicle_id;
    }

    public void setCicle_id(int cicle_id) {
        this.cicle_id = cicle_id;
    }

    public int getBuilding_id() {
        return building_id;
    }

    public void setBuilding_id(int building_id) {
        this.building_id = building_id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

}